package com.cg.dto;

public class Policy {

	private String userName;
	private String policy; 
	private int premAmount;
	private int policyNo;
	public Policy(String userName, String policy, int premAmount, int policyNo) {
		super();
		this.userName = userName;
		this.policy = policy;
		this.premAmount = premAmount;
		this.policyNo = policyNo;
	}
	public Policy() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPolicy() {
		return policy;
	}
	public void setPolicy(String policy) {
		this.policy = policy;
	}
	public int getPremAmount() {
		return premAmount;
	}
	public void setPremAmount(int premAmount) {
		this.premAmount = premAmount;
	}
	public int getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(int policyNo) {
		this.policyNo = policyNo;
	}
	
}
