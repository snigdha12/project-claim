package com.cg.dto;

public class AddUserToAgent {
	
	private String agentId;
	private String userName;
	public AddUserToAgent(String agentId, String userName) {
		super();
		this.agentId = agentId;
		this.userName = userName;
	}
	public AddUserToAgent() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getAgentId() {
		return agentId;
	}
	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
}
