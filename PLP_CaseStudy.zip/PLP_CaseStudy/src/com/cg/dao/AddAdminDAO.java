package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.exception.ICRException;
import com.cg.utiliy.JdbcUtility;

public class AddAdminDAO implements IAdminDAO{

	@Override
	public int addAdmin(String username, String password, String rolecode) throws ICRException {
		
		Connection connection = null;
		PreparedStatement statement = null;
		int rows= 0;
		try {
			connection = JdbcUtility.getConnection();
			PreparedStatement ps = connection.prepareStatement("insert into userrole values(?,?,?)");
			ps.setString(1,username);
			ps.setString(2, password);
			ps.setString(3, rolecode);
			
			 rows = ps.executeUpdate();
			System.out.println("rows"+rows);
		
	}catch(ICRException | SQLException e) {
		throw new ICRException(e.getMessage()+"problem occured in addagent DAO");
	}
		return rows;
	}
}

