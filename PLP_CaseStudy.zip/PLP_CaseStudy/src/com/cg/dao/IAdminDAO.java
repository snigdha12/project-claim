package com.cg.dao;

import com.cg.dto.Policy;
import com.cg.dto.UserRole;
import com.cg.exception.ICRException;

public interface IAdminDAO {

	int addAdmin(UserRole adminDTO) throws ICRException;
	String validate(UserRole userDTO) throws ICRException;
	int addPolicy(Policy policyDTO) throws ICRException;
}
