package com.cg.dao;

public interface QueryConstants {
	
	String ADDROLE = "insert into userrole values(?,?,?)";
	String VALIDATE = "select rolecode from userrole where username=? and pwd=?";
	String VIEWPOLICY = "select policyno,policyprem,policy_name from policy where policyno in (select policyno from policy_user where username = ?)";
	String GETQUESTIONS = "select qid,questions from question where policy_name = ?";
	String SAVEANSWER = "insert into policydetails values(?,?,?)";
	String VIEWCLAIMS = "select c.claimno,c.policyno,c.claimtype,p.policyprem from claim c,policy_user pu,policy p where c.policyno = pu.policyno and pu.policyno = p.policyno and pu.username = ?";
	String VIEWCLAIMSADMIN = "select pu.username,c.policyno,c.claimno,c.claimtype,p.policyprem from claim c,policy_user pu,policy p where c.policyno = pu.policyno and pu.policyno = p.policyno ";
}
