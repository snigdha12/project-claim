package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dao.IUserDAO;
import com.cg.dao.UserDAO;
import com.cg.dto.User;
import com.cg.exception.ICRException;

@WebServlet("/add")
public class AddUserServlet extends HttpServlet{
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		PrintWriter writer = response.getWriter();

		String userName = request.getParameter("uname");
		String password = request.getParameter("pwd");
		String roleCode = request.getParameter("rolecode");
		User userObj = new User(userName,password,roleCode);

		int rows = 0;
			IUserDAO user = new UserDAO();
			try {
				rows=user.addUser(userName, password, roleCode);
				if(rows>0)
					writer.println("user succesfully added");
				else
					writer.println("not added");
			} catch (ICRException e) {
				System.out.println(e.getMessage()+" exception in adduser servlet");
			}
		
	}
}
