package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dao.IUserDAO;
import com.cg.dao.UserDAO;
import com.cg.dto.User;
import com.cg.dto.UserRole;
import com.cg.exception.ICRException;

@WebServlet("/add")
public class AddUserServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		PrintWriter out = response.getWriter();

		String userName = request.getParameter("uname");
		String password = request.getParameter("pwd");
		String roleCode = request.getParameter("rolecode");
		long accountNo = Long.parseLong(request.getParameter("accountno"));
		RequestDispatcher dispatcher = null;
		out.println("<html><body>");
		int rows = 0;
		User userDTO = new User(userName, password, roleCode, accountNo);
		IUserDAO user = new UserDAO();
		try {
			rows = user.addUser(userDTO);
			if (rows > 0) {
				out.println("<h2>user succesfully added, please wait while redirecting to homepage</h2>");
				response.setHeader("Refresh", "2;url=adminHomePage.jsp");
			} else {
				out.println("<script type=\"text/javascript\">");
				out.println("alert('Problem while adding user, Please try again!');");
				out.println("location='addUser.jsp';");
				out.println("</script>");
			}
		} catch (ICRException e) {
			response.sendRedirect("AdminError.jsp");
			System.out.println(e.getMessage() + " exception in adduser servlet");
		}
		out.println("</html></body>");
	}
}
