package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.cg.dao.AdminDAO;
import com.cg.dao.IAdminDAO;
import com.cg.exception.ICRException;

@WebServlet("/addAdmin")
public class AddAdminServlet extends HttpServlet {
	static final Logger LOGGER = Logger.getLogger(AddAdminServlet.class);

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		    if(request.getSession().getAttribute("username")==null){
		    	LOGGER.info("Session not established");
		    	response.sendRedirect("index.jsp");
		    	
		    }
		    else {
		    	if(request.getSession().getAttribute("rolecode").equals("usr")){
		    		response.sendRedirect("userHomePage.jsp");
		    	} else if(request.getSession().getAttribute("rolecode").equals("agnt")){
		    		response.sendRedirect("agentHomePage.jsp");
		    	}
		    }
		    
		   
	}
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		PrintWriter writer = response.getWriter();

		String userName = request.getParameter("uname");
		String password = request.getParameter("pwd");
		String roleCode = request.getParameter("rolecode");
		LOGGER.info("Data retrieved from add Admin form");
		int rows = 0;
		IAdminDAO admin = new AdminDAO();
		try {
			rows = admin.addAdmin(userName, password, roleCode);
			if (rows > 0) {
				LOGGER.info("admin added successfully");
				writer.println("admin succesfully added");
			}else {
				LOGGER.info("admin not added");
				writer.println("not added");
		} }catch (ICRException e) {
			LOGGER.warn("Exception occured in addAdmin servlet");
			System.out.println(e.getMessage() + " exception in addAdmin servlet");
		}

	}
}
